package snail.pulltorefreshrecyclerview;

import android.view.View;

/**
 * Author: hzlishang
 * Data: 16/9/7 下午4:01
 * Des:
 * version:
 */
public interface IRefreshDocView {

    View getRefreshHeaderView();

    View getLoadMoreFooterView();
}
