package snail.pulltorefreshrecyclerview;

/**
 * Author: hzlishang
 * Data: 16/9/7 下午3:54
 * Des:
 * version:
 */
public interface IRefreshListener {
    void onRefresh();

    void onLoadMore();

}
