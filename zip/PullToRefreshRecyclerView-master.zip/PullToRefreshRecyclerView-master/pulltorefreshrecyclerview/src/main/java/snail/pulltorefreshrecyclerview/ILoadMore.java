package snail.pulltorefreshrecyclerview;

/**
 * Author: hzlishang
 * Data: 16/9/8 下午6:53
 * Des:
 * version:
 */
public interface ILoadMore {

    void startLoadMore();

    void completeLoadMore();

}
