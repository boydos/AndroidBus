package com.snail.labaffinity.view;

/**
 * Created by netease on 16-7-26.
 */
public class Test {
}
