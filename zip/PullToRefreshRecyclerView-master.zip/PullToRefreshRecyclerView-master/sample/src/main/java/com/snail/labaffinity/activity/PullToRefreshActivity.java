package com.snail.labaffinity.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.snail.labaffinity.R;

import snail.pulltorefreshrecyclerview.IRefreshDocView;
import snail.pulltorefreshrecyclerview.IRefreshListener;
import snail.pulltorefreshrecyclerview.PullToRefreshRecyclerView;

/**
 * Author: hzlishang
 * Data: 16/9/7 下午5:26
 * Des:
 * version:
 */
public class PullToRefreshActivity extends AppCompatActivity {
    private PullToRefreshRecyclerView mRefreshVIew;

    int count=20;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refresh);
        mRefreshVIew = (PullToRefreshRecyclerView) findViewById(R.id.refresh);
        mRefreshVIew.setCustomedHeadFooter(mrefresh);
        mRefreshVIew.setLayoutManager(new GridLayoutManager(this, 3));
        mRefreshVIew.setLayoutManager(new StaggeredGridLayoutManager(3,
                StaggeredGridLayoutManager.VERTICAL));
        mRefreshVIew.setLayoutManager(new LinearLayoutManager(this));
        mRefreshVIew.setAdapter(new RecyclerView.Adapter() {
            @Override
            public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
                TextView textView = new Button(parent.getContext());
                return new Holder(textView);
            }

            @Override
            public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
                ((Holder) holder).refresh();
            }


            @Override
            public int getItemCount() {
                return count;
            }
        });
        mRefreshVIew.enableLoadMore();
        mRefreshVIew.enableRefresh();
        mRefreshVIew.setIRefreshListener(new IRefreshListener() {
            @Override
            public void onLoadMore() {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mRefreshVIew.setHasMore(true);
                        count+=10;
                    }
                }, 1000);
            }

            @Override
            public void onRefresh() {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        count=20;
                        mRefreshVIew.completeRefresh();
                        mRefreshVIew.setHasMore(true);
                    }
                }, 1000);
            }
        });


    }
    class Holder extends RecyclerView.ViewHolder {

        public Holder(View itemView) {
            super(itemView);
            TextView textView = (TextView) itemView;
            itemView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 100));
            textView.setGravity(Gravity.CENTER);
            textView.setText("" + getAdapterPosition());
        }

        public void refresh() {
            TextView textView = (TextView) itemView;
            itemView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 200));
            textView.setGravity(Gravity.CENTER);
            textView.setText("" + getAdapterPosition());
        }
    }
    private IRefreshDocView mrefresh=new IRefreshDocView() {
        @Override
        public View getRefreshHeaderView() {
            return LayoutInflater.from(PullToRefreshActivity.this).inflate(R.layout.header, null);
        }

        @Override
        public View getLoadMoreFooterView() {
            return LayoutInflater.from(PullToRefreshActivity.this).inflate(R.layout.footer, null);
        }
    };
}
