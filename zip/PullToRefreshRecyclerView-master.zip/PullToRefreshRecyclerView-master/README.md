# PullToRefreshRecyclerView
非常简单易用的下拉刷新及上拉加载更多RecyclerView

<img src="https://github.com/happylishang/PullToRefreshRecyclerView/blob/master/capture/linear.gif" width=350/> 
<img src="https://github.com/happylishang/PullToRefreshRecyclerView/blob/master/capture/Gride.gif" width=350/>
