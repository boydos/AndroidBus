package com.example.googleplay.bean;

public class SubjectInfoBean
{
	public String des;
	public String url;
}
