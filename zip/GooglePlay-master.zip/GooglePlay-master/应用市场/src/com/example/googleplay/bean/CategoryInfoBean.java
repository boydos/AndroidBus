package com.example.googleplay.bean;

public class CategoryInfoBean
{
	public String title;
	public boolean isTitle;
	
	public String name1;
	public String name2;
	public String name3;
	public String url1;
	public String url2;
	public String url3;
	
}
