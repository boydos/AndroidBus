package com.example.googleplay.bean;

import java.util.List;

public class HomeBean
{
	public List<AppInfoBean> list;
	public List<String> picture;
}
